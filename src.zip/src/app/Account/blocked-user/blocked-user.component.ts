import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blocked-user',
  templateUrl: './blocked-user.component.html',
  styleUrls: ['./blocked-user.component.css']
})
export class BlockedUserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
