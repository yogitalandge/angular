  GitHub link: https://github.com/yogitalandge/pixogram/tree/master/mypixogram

  Case study status: UI layer
  Tech             : HTML,CSS,BootStrap,Angular
  